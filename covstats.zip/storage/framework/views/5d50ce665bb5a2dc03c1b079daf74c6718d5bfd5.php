
<?php $__env->startSection('title', 'Coronavirus Update'); ?>
<?php $__env->startSection('style'); ?>
<style>
	.nk-tb-list .tb-country .name{
	font-weight: 600!important;
    color: var(--paleGray)!important;		
	}
	.infect{
	font-weight: 600!important;
	color: rgb(248, 245, 64)!important;
	}
	.infect-hr{
	font-weight: 600!important;
	color: #ffc137!important;
	}
	.death{
	font-weight: 600!important;
	color: #F65164!important;
	}
	.recover{
	font-weight: 600!important;
	color: rgb(101, 221, 155)!important;
	}
	.active{
	font-weight: 600!important;
	color: rgb(68, 155, 226)!important;
	}
	.serious{
	font-weight: 600!important;
	color: #FF9D00!important;
	}
	.nk-tb-col-action{

	}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	
<?php if(!empty($countries)): ?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between flex-wrap g-1 align-start">
        <div class="nk-block-head-content">
            <h5 class="nk-block-title">Coronavirus Live Update | CovidRadar24</h5>
        </div>
        <div class="nk-block-head-content">
            <p class="note-text">Updated: <?php echo e($last_update); ?></p>
        </div>
    </div>
</div>
<div class="nk-block">
	<div class="row g-gs">
	    <div class="col-xl-8">
	        <div class="card card-bordered nk-cov-wg8">
	            <div class="card-inner">
	                <div class="nk-cov-wg8-group g-3">
	                    <div class="nk-cov-wg8-map mr-lg-5">
	                        <div class="vector-map" id="worldMap"></div>
	                    </div>
	                </div>
	            </div>
	            <div class="card-inner border-top">
	                <div class="card-title-group">
	                    <div class="card-title">
	                        <h6 class="title align-center"><span class="mr-2">Statistics</span> <em class="icon ni ni-info text-primary fs-14px" data-toggle="tooltip" title="tolltip"></em></h6>
	                    </div>
	                    <div class="card-tools">
	                        <ul class="card-tools-nav">
	                            <li class="" id="lastweek"><a class="link" href="#">Last Week</a></li>	                        	
	                            <li class="" id="twodaysago"><a class="link" href="#">2Days Ago</a></li>	                        	
	                        	<li class="" id="yesterday"><a class="link" href="#">Yesterday</a></li>
	                            <li class="active" id="today"><a class="link" href="#">Now</a></li>
	                        </ul>
	                    </div>
	                </div>
	            </div>
	            <div class="card-inner p-0 border-top nk-cov-wg8-table-wrap">
	                <table class="nk-tb-list nk-tb-covid nk-tb-countries is-medium">
	                    <thead>
	                        <tr class="nk-tb-item nk-tb-head">
	                            <th class="nk-tb-col nk-tb-col-country cov-sortable"><span>Country</span></th>
	                            <th class="nk-tb-col nk-tb-col-infect cov-sortable sort-down"><span>Infected</span></th>
	                            <th class="nk-tb-col nk-tb-col-infect-hr cov-sortable"><span>In Last 24h</span></th>
	                            <th class="nk-tb-col nk-tb-col-death cov-sortable"><span>Deaths</span></th>
	                            <th class="nk-tb-col nk-tb-col-recover cov-sortable"><span>Recovered</span></th>
	                            <th class="nk-tb-col nk-tb-col-active cov-sortable"><span>Active Cases</span></th>
	                            <th class="nk-tb-col nk-tb-col-serious cov-sortable"><span>Serious</span></th>
	                            <th class="nk-tb-col nk-tb-col-action"><span>&nbsp;</span></th>
	                        </tr>
	                    </thead>
	                </table>
	                <div class="nk-cov-table-pro" data-simplebar>
	                    <table class="nk-tb-list nk-tb-covid nk-tb-countries cov-datatable is-medium">
	                        <thead>
	                            <tr class="nk-tb-item nk-tb-head">
	                                <th class="nk-tb-col nk-tb-col-country"><span>Country</span></th>
	                                <th class="nk-tb-col nk-tb-col-infect"><span>Infected</span></th>
	                                <th class="nk-tb-col nk-tb-col-infect-hr"><span>In Last 24h</span></th>
	                                <th class="nk-tb-col nk-tb-col-death"><span>Deaths</span></th>
	                                <th class="nk-tb-col nk-tb-col-recover"><span>Recovered</span></th>
	                                <th class="nk-tb-col nk-tb-col-active"><span>Active Cases</span></th>
	                                <th class="nk-tb-col nk-tb-col-serious"><span>Serious</span></th>
	                                <th class="nk-tb-col nk-tb-col-action nk-tb-col-nosort" data-priority="1"><span></span></th>
	                            </tr>
	                        </thead>
	                        <tbody id="tbody">
	                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $locat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            	<?php if($code !='world' && $locat['cases']): ?>

                            	<tr class="nk-tb-item<?php echo e(($locat['cases'] >= 50 && !($code=='xz'||$code=='xd')) ? ' get-details' : ''); ?>" data-code="<?php echo e(strtolower($locat['country']['code'])); ?>" data-location="<?php echo e($locat['country']['name']); ?>">
	                                <td class="nk-tb-col nk-tb-col-country">
	                                    <div class="tb-country">
	                                        <img class="flag" src="<?php echo e(asset('images/flags/'.strtolower($locat['country']['code']).'.png')); ?>" alt="<?php echo e($locat['country']['name']); ?>">
	                                        <div class="name"><?php echo e($locat['country']['name']); ?></div>
	                                    </div>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-infect">
	                                    <span class="tb-lead tb-lead-sub infect"><?php echo e(number_format($locat['cases'])); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-infect-hr">
	                                    <span class="tb-lead tb-lead-sub infect-hr" style="display: inline;"><?php echo e(($locat['today']['cases']) ? '+'.number_format($locat['today']['cases']) : ''); ?>

	                                    </span>
	                                    <span style="font-weight: 600!important;color: var(--paleGray)!important;"><?php echo e(($locat['today']['death']) ? ' | ' : ''); ?>

	                                    </span>
	                                    <span style="font-weight: 600!important;color: #F65164!important;"><?php echo e(($locat['today']['death']) ? '+'.number_format($locat['today']['death']) : ''); ?>

	                                    </span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-death">
	                                    <span class="tb-lead tb-lead-sub death"><?php echo e(($locat['death']) ? number_format($locat['death']) : ''); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-recover">
	                                    <span class="tb-lead tb-lead-sub recover"><?php echo e(($locat['recovered']) ? number_format($locat['recovered']) : ''); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-active">
	                                    <span class="tb-lead tb-lead-sub active"><?php echo e(($locat['active']) ? number_format($locat['active']) : ''); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-serious">
	                                    <span class="tb-lead tb-lead-sub serious"><?php echo e(($locat['critical']) ? number_format($locat['critical']) : ''); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-action">
	                                	<?php if($locat['cases'] >= 50 && !($code=='xz'||$code=='xd')): ?>
	                                    <a class="btn btn-sm btn-icon btn-trigger mr-n2"><em class="icon ni ni-chevron-right"></em></a>
	                                    <?php endif; ?> 
	                                </td>
	                            </tr>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                        </tbody>
	                    </table>
	                </div>
	            </div>
	        </div>
	    </div>
	    <div class="col-xl-4">
	        <div class="row g-gs">
	            <div class="col-xl-12 col-lg-6">
	                <div class="card card-bordered card-full">
	                    <div class="card-inner">
	                        <div class="card-title-group mb-1">
	                            <div class="card-title">
	                                <h6 class="title">Spread over time <small> - World</small></h6>
	                                <p>Chart shown how spread over time.</p>
	                            </div>
	                        </div>
	                        <div class="nk-cov-wg6">
	                            <ul class="nav nav-tabs nav-tabs-card nav-tabs-xs">
	                                <li class="nav-item">
	                                    <a class="nav-link active" data-toggle="tab" href="#daily-increase">Daily Increase</a>
	                                </li>	                            	
	                                <li class="nav-item">
	                                    <a class="nav-link" data-toggle="tab" href="#confirmed-cases">Confirmed Cases</a>
	                                </li>
	                            </ul>
	                            <div class="tab-content mt-0">
	                                <div class="tab-pane active" id="daily-increase">
	                                    <ul class="nk-cov-wg6-legend">
	                                        <li>
	                                            <div class="dot dot-md sq bg-primary"></div>
	                                            <span>Confirmed</span>
	                                        </li>
	                                    </ul>
	                                    <div class="nk-cov-wg6-ck">
	                                        <canvas class="covid-case-bar-chart" id="worldDaily"></canvas>
	                                    </div>
	                                    <div class="chart-label-group ml-5">
	                                        <div class="chart-label"><?php echo e($graphs['world_daily']->first); ?></div>
	                                        <div class="chart-label"><?php echo e($graphs['world_daily']->last); ?></div>
	                                    </div>
	                                </div>	                            	
	                                <div class="tab-pane" id="confirmed-cases">
	                                    <ul class="nk-cov-wg6-legend">
	                                        <li>
	                                            <div class="dot dot-md sq bg-primary"></div>
	                                            <span>Confirmed</span>
	                                        </li>
	                                    </ul>
	                                    <div class="nk-cov-wg6-ck">
	                                        <canvas class="covid-case-line-chart" id="worldTimeline"></canvas>
	                                    </div>
	                                    <div class="chart-label-group ml-5">
	                                        <div class="chart-label"><?php echo e($graphs['world_timeline']->first); ?></div>
	                                        <div class="chart-label"><?php echo e($graphs['world_timeline']->last); ?></div>
	                                    </div>
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <div class="col-xl-12 col-lg-6">
	                <div class="card card-bordered card-full">
	                    <div class="card-inner">
	                        <div class="card-title-group mb-4">
	                            <div class="card-title">
	                                <h6 class="title">Comparison over time <small> - World</small></h6>
	                                <p>Comparison of daily cases, death & recovered.</p>
	                            </div>
	                        </div>
	                        <div class="nk-cov-wg6">
	                            <div class="nk-cov-wg6-ck-lg">
	                                <canvas class="covid-case-line-chart" id="worldSpread"></canvas>
	                            </div>
	                            <div class="chart-label-group ml-5">
	                                <div class="chart-label"><?php echo e($graphs['world_timeline']->first); ?></div>
	                                <div class="chart-label"><?php echo e($graphs['world_timeline']->last); ?></div>
	                            </div>
	                            <ul class="nk-cov-wg6-legend mb-n1">
	                                <li>
	                                    <div class="dot dot-md sq bg-primary"></div>
	                                    <span>Confirm Cases</span>
	                                </li>
	                                <li>
	                                    <div class="dot dot-md sq bg-success"></div>
	                                    <span>Recovered</span>
	                                </li>
	                                <li>
	                                    <div class="dot dot-md sq bg-danger"></div>
	                                    <span>Deaths</span>
	                                </li>
	                            </ul>
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <div class="col-xl-12">
	                <div class="card card-bordered card-full">
	                    <div class="card-inner">
	                        <div class="card-title-group mb-4">
	                            <div class="card-title">
	                                <h6 class="title">Worldwide Affected Ratio</h6>
                            		<p>The bar show most affected country in ratio.</p>
	                            </div>
	                        </div>
	                        <div class="nk-cov-wg7">
	                            <div class="nk-cov-wg7-list gy-1">
		                            <?php $__currentLoopData = $affect_ratio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                            <div class="nk-cov-wg7-data">
		                                <div class="nk-cov-wg7-data-title">
		                                    <div class="lead-text"><?php echo e($item['name']); ?></div>
		                                </div>
		                                <div class="nk-cov-wg7-data-progress">
		                                    <div class="progress progress-alt bg-transparent">
		                                        <div class="progress-bar" data-bg="<?php echo e($item['color']); ?>" data-progress="<?php echo e(($item['percent'] * 1.5)); ?>"></div>
		                                        <div class="progress-amount"><?php echo e($item['percent']); ?>%</div>
		                                    </div>
		                                </div>
		                                <div class="nk-cov-wg7-data-count text-right">
		                                    <div class="sub-text"><?php echo e($item['cases']); ?></div>
		                                </div>
		                            </div>
		                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footer'); ?>
<?php if(!empty($countries)): ?>
<script src="<?php echo e(asset('assets/js/libs/jqvmap.js?ver=100')); ?>"></script>
<script src="<?php echo e(asset('assets/js/chart-covstats.js?ver=100')); ?>"></script>
<script type="text/javascript">
	var countryUri = "<?php echo e(route('country.details')); ?>";
    var worldMap = { map: 'world_en', data : <?php echo $graphs['map']; ?> },
        worldTimeline = {
            labels : [<?php echo $graphs['world_timeline']->labels; ?>],
            dataUnit : 'People',
            lineTension : 0.1,
            datasets : [{
                label : "Confirmed",
                color : "#0971fe",
                background: 'transparent',
                data: [<?php echo $graphs['world_timeline']->data['cases']; ?>]
            }]
        }, 
        worldDaily = {
            labels : [<?php echo $graphs['world_daily']->labels; ?>],
            dataUnit : 'People',
            lineTension : 0.1,
            datasets : [{
                label : "Confirmed",
                color : "#0971fe",
                background: 'transparent',
                data: [<?php echo $graphs['world_daily']->data['cases']; ?>]
            }]
        },
        worldSpread = {
            labels : [<?php echo $graphs['world_timeline']->labels; ?>],
            dataUnit : 'People',
            lineTension : 0.1,
            datasets : [{
                label : "Confirmed",
                color : "#0971fe",
                background: 'transparent',
                data: [<?php echo $graphs['world_timeline']->data['cases']; ?>]
            }, {
                label : "Deaths",
                color : "#f6525e",
                background: 'transparent',
                data: [<?php echo $graphs['world_timeline']->data['deaths']; ?>]
            }, {
                label : "Recovered",
                color : "#1ee0ac",
                background: 'transparent',
                data: [<?php echo $graphs['world_timeline']->data['recovered']; ?>]
            }]
        };
</script>
<script type="text/javascript">
	$( "#yesterday" ).click(function() {
		event.preventDefault();
		if(!$(this).hasClass( "active" )){
			  	$(this).addClass('active');
			  }
		if($("#today").hasClass( "active" )){
			  	$("#today").removeClass('active');
			  }	
		if($("#lastweek").hasClass( "active" )){
			  	$("#lastweek").removeClass('active');
			  }
		if($("#twodaysago").hasClass( "active" )){
			  	$("#twodaysago").removeClass('active');
			  }			  
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
               jQuery.ajax({
                  url: "<?php echo e(url('/countries-ajax')); ?>",
                  method: 'post',
                  data: {
                     date: 'yesterday'
                  },
                  success: function(result){

                    if(result.tbody) {
                    $('#tbody').html(result.tbody);
                }
                  }});
});

	$( "#today" ).click(function() {
		event.preventDefault();
		if(!$(this).hasClass( "active" )){
			  	$(this).addClass('active');
			  }
		if($("#yesterday").hasClass( "active" )){
			  	$("#yesterday").removeClass('active');
			  }	
		if($("#lastweek").hasClass( "active" )){
			  	$("#lastweek").removeClass('active');
			  }
		if($("#twodaysago").hasClass( "active" )){
			  	$("#twodaysago").removeClass('active');
			  }	
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
               jQuery.ajax({
                  url: "<?php echo e(url('/countries-ajax')); ?>",
                  method: 'post',
                  data: {
                     date: 'today'
                  },
                  success: function(result){

                    if(result.tbody) {
                    $('#tbody').html(result.tbody);
                }
                  }});			  			  
});
	$( "#twodaysago" ).click(function() {
		event.preventDefault();
		if(!$(this).hasClass( "active" )){
			  	$(this).addClass('active');
			  }
		if($("#yesterday").hasClass( "active" )){
			  	$("#yesterday").removeClass('active');
			  }	
		if($("#lastweek").hasClass( "active" )){
			  	$("#lastweek").removeClass('active');
			  }
		if($("#today").hasClass( "active" )){
			  	$("#today").removeClass('active');
			  }	
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
               jQuery.ajax({
                  url: "<?php echo e(url('/countries-ajax')); ?>",
                  method: 'post',
                  data: {
                     date: 'twodaysago'
                  },
                  success: function(result){

                    if(result.tbody) {
                    $('#tbody').html(result.tbody);
                }
                  }});			  			  
});	
	$( "#lastweek" ).click(function() {
		event.preventDefault();
		if(!$(this).hasClass( "active" )){
			  	$(this).addClass('active');
			  }
		if($("#yesterday").hasClass( "active" )){
			  	$("#yesterday").removeClass('active');
			  }	
		if($("#today").hasClass( "active" )){
			  	$("#today").removeClass('active');
			  }
		if($("#twodaysago").hasClass( "active" )){
			  	$("#twodaysago").removeClass('active');
			  }	
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
               jQuery.ajax({
                  url: "<?php echo e(url('/countries-ajax')); ?>",
                  method: 'post',
                  data: {
                     date: 'lastweek'
                  },
                  success: function(result){

                    if(result.tbody) {
                    $('#tbody').html(result.tbody);
                }
                  }});			  			  
});		
	function opencountrymodal(code,location) {
            $.get(countryUri, {
                code: code,
                location:location
            }).done(function(res){
                if(res.modal) {
                    var $modal = $('#ajax-modal').html('');
                    $modal.html(res.modal);
                    $modal = $modal.find('.modal');
                    if($modal.length > 0){
                        $modal.modal('show');
                    }
                }
            });
    
}
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\covstats\covstats\resources\views/countries.blade.php ENDPATH**/ ?>