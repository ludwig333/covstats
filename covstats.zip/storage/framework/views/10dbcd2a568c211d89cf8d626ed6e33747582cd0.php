	                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            	<?php if($locat->code !='global' && $locat->cases): ?>

                            	<tr class="nk-tb-item<?php echo e(($locat->cases >= 50 && !($locat->code=='xz'||$locat->code=='xd')) ? ' get-details' : ''); ?>" data-code="<?php echo e(strtolower($locat->code)); ?>" data-location="<?php echo e($locat->name); ?>" onclick="opencountrymodal('<?php echo e(strtolower($locat->code)); ?>','<?php echo e($locat->name); ?>');">
	                                <td class="nk-tb-col nk-tb-col-country">
	                                    <div class="tb-country">
	                                        <img class="flag" src="<?php echo e(asset('images/flags/'.strtolower($locat->code).'.png')); ?>" alt="<?php echo e($locat->name); ?>">
	                                        <div class="name"><?php echo e($locat['name']); ?></div>
	                                    </div>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-infect">
	                                    <span class="tb-lead tb-lead-sub infect"><?php echo e(number_format($locat->cases)); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-infect-hr">
	                                    <span class="tb-lead tb-lead-sub infect-hr" style="display: inline;"><?php echo e(($locat->today_cases) ? '+'.number_format($locat->today_cases) : ''); ?>

	                                    </span>
	                                    <span style="font-weight: 600!important;color: var(--paleGray)!important;"><?php echo e(($locat->today_death) ? ' | ' : ''); ?>

	                                    </span>
	                                    <span style="font-weight: 600!important;color: #F65164!important;"><?php echo e(($locat->today_death) ? '+'.number_format($locat->today_death) : ''); ?>

	                                    </span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-death">
	                                    <span class="tb-lead tb-lead-sub death"><?php echo e(($locat->death) ? number_format($locat->death) : ''); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-recover">
	                                    <span class="tb-lead tb-lead-sub recover"><?php echo e(($locat->recovered) ? number_format($locat->recovered) : ''); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-active">
	                                    <span class="tb-lead tb-lead-sub active"><?php echo e(($locat->active) ? number_format($locat->active) : ''); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-serious">
	                                    <span class="tb-lead tb-lead-sub serious"><?php echo e(($locat->critical) ? number_format($locat->critical) : ''); ?></span>
	                                </td>
	                                <td class="nk-tb-col nk-tb-col-action">
	                                	<?php if($locat->cases >= 50 && !($locat->code=='xz'||$locat->code=='xd')): ?>
	                                    <a class="btn btn-sm btn-icon btn-trigger mr-n2"><em class="icon ni ni-chevron-right"></em></a>
	                                    <?php endif; ?> 
	                                </td>
	                            </tr>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\work\covstats\covstats\resources\views/countries-table-other.blade.php ENDPATH**/ ?>